from flask import Flask, render_template, request
import pickle
import numpy as np
import os

app = Flask(__name__)

# Project folder path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Load Random Forest model
with open(os.path.join(BASE_DIR, "regression-rf-model.pkl"), "rb") as f:
    model = pickle.load(f)


# Load label encoders created in your notebook
def load_encoder(filename):
    with open(os.path.join(BASE_DIR, filename), "rb") as f:
        return pickle.load(f)


lb_brand = load_encoder("lb_brand.pkl")
lb_processorname = load_encoder("lb_processorname.pkl")
lb_ramgb = load_encoder("lb_ramgb.pkl")
lb_ramtype = load_encoder("lb_ramtype.pkl")
lb_ssd = load_encoder("lb_ssd.pkl")
lb_hdd = load_encoder("lb_hdd.pkl")
lb_os = load_encoder("lb_os.pkl")
lb_osbit = load_encoder("lb_osbit.pkl")
lb_graphiccardgb = load_encoder("lb_graphiccardgb.pkl")
lb_warranty = load_encoder("lb_warranty.pkl")
lb_Touchscreen = load_encoder("lb_Touchscreen.pkl")
lb_rating = load_encoder("lb_rating.pkl")


# Options taken from your notebook
options = {
    "brand": list(lb_brand.classes_),
    "processor_brand": ["Intel", "AMD", "M1"],
    "processor_name": list(lb_processorname.classes_),
    "ram_gb": list(lb_ramgb.classes_),
    "ram_type": list(lb_ramtype.classes_),
    "ssd": list(lb_ssd.classes_),
    "hdd": list(lb_hdd.classes_),
    "os": list(lb_os.classes_),
    "os_bit": list(lb_osbit.classes_),
    "graphic_card_gb": list(lb_graphiccardgb.classes_),
    "warranty": list(lb_warranty.classes_),
    "Touchscreen": list(lb_Touchscreen.classes_),
    "rating": list(lb_rating.classes_)
}


@app.route("/", methods=["GET", "POST"])
def home():

    predicted_price = None
    error = None

    if request.method == "POST":

        try:
            # Get details from HTML form
            brand = request.form["brand"]
            processor_brand = request.form["processor_brand"]
            processor_name = request.form["processor_name"]
            ram_gb = request.form["ram_gb"]
            ram_type = request.form["ram_type"]
            ssd = request.form["ssd"]
            hdd = request.form["hdd"]
            os_name = request.form["os"]
            os_bit = request.form["os_bit"]
            graphic_card_gb = request.form["graphic_card_gb"]
            warranty = request.form["warranty"]
            touchscreen = request.form["Touchscreen"]
            rating = request.form["rating"]

            number_of_ratings = int(
                request.form["Number_of_Ratings"]
            )

            number_of_reviews = int(
                request.form["Number_of_Reviews"]
            )

            if number_of_ratings < 0 or number_of_reviews < 0:
                raise ValueError("Ratings and reviews cannot be negative.")

            # Encode categorical inputs
            brand = lb_brand.transform([brand])[0]

            processor_brand = {
                "Intel": 0,
                "AMD": 1,
                "M1": 2
            }[processor_brand]

            processor_name = lb_processorname.transform(
                [processor_name]
            )[0]

            ram_gb = lb_ramgb.transform([ram_gb])[0]
            ram_type = lb_ramtype.transform([ram_type])[0]
            ssd = lb_ssd.transform([ssd])[0]
            hdd = lb_hdd.transform([hdd])[0]
            os_name = lb_os.transform([os_name])[0]
            os_bit = lb_osbit.transform([os_bit])[0]

            graphic_card_gb = lb_graphiccardgb.transform(
                [graphic_card_gb]
            )[0]

            warranty = lb_warranty.transform([warranty])[0]

            touchscreen = lb_Touchscreen.transform(
                [touchscreen]
            )[0]

            rating = lb_rating.transform([rating])[0]

            # Feature order follows x.columns in your notebook
            input_data = np.array([[
                brand,
                processor_brand,
                processor_name,
                ram_gb,
                ram_type,
                ssd,
                hdd,
                os_name,
                os_bit,
                graphic_card_gb,
                warranty,
                touchscreen,
                rating,
                number_of_ratings,
                number_of_reviews
            ]])

            # Predict laptop price
            prediction = model.predict(input_data)[0]

            predicted_price = max(0, round(float(prediction), 2))

        except (ValueError, KeyError) as e:
            error = str(e)

        except Exception:
            error = "Unable to predict. Please check your model files."

    return render_template(
        "index.html",
        options=options,
        predicted_price=predicted_price,
        error=error
    )


if __name__ == "__main__":
    app.run(debug=True)